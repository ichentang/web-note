//
//  AppDelegate.h
//  FlutterHybridiOS
//
//  Created by jph on 2019/2/25.
//  Copyright © 2019 devio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

