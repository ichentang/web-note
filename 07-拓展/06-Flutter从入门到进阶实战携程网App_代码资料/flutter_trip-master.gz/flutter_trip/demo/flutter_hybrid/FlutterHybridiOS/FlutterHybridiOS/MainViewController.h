//
//  MianViewController.h
//  FlutterHybridiOS
//
//  Created by jph on 2019/2/27.
//  Copyright © 2019 devio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Flutter/Flutter.h>
@interface MainViewController : UIViewController
@property(strong)NSString *inputParams;
@end
