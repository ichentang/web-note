//
//  FirstViewController.h
//  FlutterHybridiOS
//
//  Created by jph on 2019/2/27.
//  Copyright © 2019 devio. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FirstViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *inputParams;

@end

NS_ASSUME_NONNULL_END
